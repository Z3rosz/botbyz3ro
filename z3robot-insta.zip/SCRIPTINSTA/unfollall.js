'use strict'

const Client = require('instagram-private-api').V1;
const delay = require('delay');
const chalk = require('chalk');
const _ = require('lodash');
const inquirer = require('inquirer');

const User = [
{
  type:'input',
  name:'username',
  message:'[>] Inserir usuario:',
  validate: function(value){
    if(!value) return 'nenhum valor inserido';
    return true;
  }
},
{
  type:'password',
  name:'password',
  message:'[>] Inserir senha:',
  mask:'*',
  validate: function(value){
    if(!value) return 'nenhum valor inserido';
    return true;
  }
},
{
  type:'input',
  name:'mysyntx',
  message:'[>] Insira o valor que deseja deixar de seguir:(max/99999)',
  validate: function(value){
    value = value.match(/[0-9]/);
    if (value) return true;
    return 'Use Number Only!';
  }
},
{
  type:'input',
  name:'sleep',
  message:'[>] Inserir pausa (MiliSegundos):',
  validate: function(value){
    value = value.match(/[0-9]/);
    if (value) return true;
    return 'Delay is number';
  }
}
]

const Login = async function(User){

  const Device = new Client.Device(User.username);
  const Storage = new Client.CookieMemoryStorage();
  const session = new Client.Session(Device, Storage);

  try {
    await Client.Session.create(Device, Storage, User.username, User.password)
    const account = await session.getAccount();
    return Promise.resolve({session,account});
  } catch (err) {
    return Promise.reject(err);
  }

}

const Unfollow = async function(session, accountId){
  try {
    await Client.Relationship.destroy(session, accountId);
    return chalk`{bold.green Sucesso}`;
  } catch (err){
    return chalk`{bold.red Falhou}`;
  }
}

const Excute = async function(User,sleep,mysyntx){

  try {
    console.log(chalk`{yellow [?] Tentando Login . . .}`);
    const doLogin = await Login(User);
    console.log(chalk`{green [!] Sucesso, }{yellow [?] Deixando de seguir . . .}`)
    const feed = new Client.Feed.AccountFollowing(doLogin.session, doLogin.account.id);
    var cursor;
    do{
      if (cursor) feed.setCursor(cursor);
      var getPollowers = await feed.get();
      getPollowers = _.chunk(getPollowers, mysyntx);
      for (let i = 0; i < getPollowers.length; i++) {
        var timeNow = new Date();
        timeNow = `${timeNow.getHours()}:${timeNow.getMinutes()}:${timeNow.getSeconds()}`
        await Promise.all(getPollowers[i].map(async(account) => {
          const doUnfollow = await Unfollow(doLogin.session, account.id);
          console.log(chalk`[{magenta ${timeNow}}] Unfollow {yellow @${account.params.username}} => ${doUnfollow}`);
        }));
        console.log(chalk`{yellow \n [#][>] Pausa de ${sleep} MiliSegundos [<][#] \n}`);
        await delay(sleep);
      }
      cursor = await feed.getCursor();
    } while(feed.isMoreAvailable())
    console.log(chalk`{bold.green [+] Deixou de seguir}`)
  } catch(e) {
    console.log(e)
  }
}

console.log(chalk`
  {bold.cyan
  —————————————————— [INFORMATION] ————————————————————

  [?] {bold.green ESSA OPÇÃO VAI APAGAR TODOS QUE VOCÊ ESTÁ SEGUINDO!}

  ——————————————————  [CRÉDITOS]  ————————————————————

  [✓] CODE BY @Z3rosz
  [✓] Telegram: @Z3rosz
  [✓] Whatsapp: +1 (709) 300-1027  
 
  —————————————————————————————————————————————————————}
      `);

inquirer.prompt(User)
.then(answers => {
  Excute({
    username:answers.username,
    password:answers.password
  },answers.sleep,answers.mysyntx);
})
