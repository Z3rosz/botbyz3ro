'use strict'

//const insta = require('./func.js'); 
const Client = require('instagram-private-api').V1;
const delay = require('delay');
const chalk = require('chalk');
const inquirer = require('inquirer');
//const Spinner = require('cli-spinner').Spinner;

const questionTools = [
  {
    type:"list",
    name:"Tools",
    message:"Selecione uma opção:",
    choices:
      [
      
        "[1] Excluir Publicações",
        "[2] Deixar de seguir todos que sigo",
        "[3] Seguir pessoas por publicação",
        "[4] Seguir pessoas por hashtag",
	      "[5] Seguir seguidores de um alvo(@)",
        "\n"
      ] 
  }
]

const main = async () => {
  var spinner;
  try{
    var toolChoise = await inquirer.prompt(questionTools);
    toolChoise = toolChoise.Tools;
    switch(toolChoise){
      case "[1] Excluir Publicações":
        const dellallphoto = require('./dellallphoto.js');
        await dellallphoto();
        break;

      case "[2] Deixar de seguir todos que sigo":
        const unfollall = require('./unfollall.js');
        await unfollall();
        break;

      case "[3] Seguir pessoas por publicação":
        const flmauto = require('./flmauto.js');
        await flmauto();
        break;

      case "[4] Seguir pessoas por hashtag":
        const fah = require('./fah1.js');
        await fah();
        break;

	   case "[5] Seguir seguidores de um alvo(@)":
        const fftold = require('./fftold.js');
        await fftold();
        break;
        
      default:
        console.log('\nERROR:\n[?] Poxa! \n[!] Algo deu errado!\n[!] Por favor tente novamente!');
    }
  } catch(e) {
    //spinner.stop(true);
    //console.log(e);
  }
}

console.log(chalk`
  {bold.cyan
......888888.888888.8888888..8888888......
..........88.88.....88....88.88...88......
.........88..88888..88....88.88...88......
........88...88.....8888888..88...88......
.......88....88.....88....88.88...88......
......888888.888888.88....88.8888888......
               
               BOT INSTAGRAM
                by: @Z3rosz
}
      `);

main()
